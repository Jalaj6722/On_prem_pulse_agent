#!/usr/bin/env python3
"""
Pulse Agent - Entry point script
"""

from pulse_agent_complete.main import main

if __name__ == "__main__":
    import sys
    sys.exit(main())
