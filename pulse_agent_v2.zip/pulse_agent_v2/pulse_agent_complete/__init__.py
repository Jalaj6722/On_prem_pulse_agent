"""
Pulse Agent - Lightweight Python agent for data collection and synchronization
"""

__version__ = "1.0.0"
